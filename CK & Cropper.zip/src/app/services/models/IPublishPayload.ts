export interface IPublishPayload {
    firstDropdown: string;
    secondDropdown: string;
    description: string;
    publishDate: string;
    template: string;
    image: string;
}