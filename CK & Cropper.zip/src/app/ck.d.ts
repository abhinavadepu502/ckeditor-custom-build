
declare module '@ckeditor/ckeditor5-build-classic' {
    const x : any;
    export = x;
  }